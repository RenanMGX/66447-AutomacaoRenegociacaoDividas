from Entities.imobme import Imobme
import pandas as pd
from Entities import exceptions
from Entities.preparar_dados import PrepararDados


if __name__ == '__main__':
    path = r"#material\RETORNO - KITEI 1.xlsx"
    
    
    df = pd.read_excel(path)    
    
    df = PrepararDados.preparar_dados(path)
    if PrepararDados.validar_dados(df):
        bot = Imobme(headless=False)
        
        retorno = {}
        for row, value in df.iterrows():
            if value['Observação'] == "Sucesso!":
                retorno[row] = "Sucesso!"
                continue
            try:
                response = bot.registrar_renegociacao(value.to_dict())
            except Exception as e:
                response = f"Exceção não tratada: {type(e)}, {str(e)}"
            
            retorno[row] = response
            #retorno[row] = f"Testes do contrato {value['Numero do contrato']}"
            #break
        bot.quit()
            
        PrepararDados.regitrar_retorno(path=path, retorno=retorno)
        
        #print(retorno)
    
    #import pdb;pdb.set_trace()
    